/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int a;
    printf("Enter the Value of a\n");
    scanf("%d",&a);
    if(a%2==0){
        printf("a is even Number\n");
    }
    else{
        printf("a is odd Number\n");
    }
    

    return 0;
}
