/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int a,b,c;
    printf("Enter the value of a\n");
    scanf("%d" ,&a);
    printf("Enter the value of b\n");
    scanf("%d" ,&b);
    printf("Enter \n1.addition\n2.substraction\n3.multiplication\n4.division\n");
    
    scanf("%d" ,&c);
    switch(c){
        case 1:
            printf("addition of a and b is %d",a+b);
            break;
        case 2:
            printf("Substraction of a and b is %d",a-b);
            break;
        case 3:
            printf("multiplication of a and b is %d",a*b);
            break;
        case 4:
            printf("division of a and b is %d",a/b);
            break;
        default:
            printf("Enter numbers between 1 and 4");
    }
    

    return 0;
}

